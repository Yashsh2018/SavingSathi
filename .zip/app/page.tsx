'use client';

import Index from "./Home/Index";

function Home() {
  return (
    <Index />
  )
}

export default Home
